# Facial Expression Expressiveness Recognition System

A new facial expression recognition system that classifies facial expressions into **expressiveness levels** rather than traditional emotions (Ekman's 7 emotions).

## What's Different

| Feature | Original System | This System |
|---------|-----------------|-------------|
| **Emotions** | 7 emotions (anger, disgust, fear, happiness, sadness, surprise, neutral) | 3 expressiveness levels (Reserved, Balanced, Expressive) |
| **Face Detection** | OpenCV Haar cascades | MediaPipe (Google's modern framework) |
| **Deep Learning** | PyTorch + TorchVision | TensorFlow/Keras |
| **Dataset** | FER2013 (general faces) | RecruitView_Data (interview videos) |
| **Purpose** | General emotion recognition | Interview facial expressiveness analysis |

## Quick Start

### 1. Activate Virtual Environment
```bash
# Windows
facial_expressiveness_env\Scripts\activate

# Or use the batch file
activate_env.bat
```

### 2. Install Dependencies (if not already installed)
```bash
pip install -r requirements.txt
```

### 3. Test the System
```bash
python test_system.py
```

### 4. Run Real-time Recognition
```bash
python real_time_demo.py
```

### 5. Train Your Own Model
Open the notebook in Jupyter:
```bash
jupyter notebook Facial_Expression_Expressiveness_Recognition.ipynb
```

## Project Structure

```
FYP/
├── facial_expressiveness_env/          # Virtual environment
├── Facial_Expression_Expressiveness_Recognition.ipynb  # Main notebook
├── real_time_demo.py                   # Real-time demo
├── test_system.py                      # System test
├── analyze_facial_data.py             # Data analysis
├── setup_environment.py               # Environment setup
├── activate_env.bat                    # Environment activation
├── requirements.txt                    # Dependencies
├── USAGE_GUIDE.md                      # Detailed usage guide
└── FYP/RecruitView_Data/              # Dataset
    ├── metadata.jsonl                 # Interview metadata
    └── videos/                        # Interview videos
```

## Expressiveness Categories

The system classifies facial expressions into 3 levels based on statistical analysis of interview data:

- **Reserved Expression**: Low expressiveness (score ≤ -0.303)
- **Balanced Expression**: Neutral expressiveness (-0.303 < score ≤ 0.294)
- **Expressive**: High expressiveness (score > 0.294)

## Key Features

✅ **Modern Tech Stack**: MediaPipe + TensorFlow instead of OpenCV + PyTorch
✅ **Domain-Specific**: Trained on interview videos, not general faces
✅ **Expressiveness Focus**: Measures communication style, not just emotions
✅ **Real-time Recognition**: Webcam-based live facial analysis
✅ **Balanced Categories**: Uses percentiles for fair category distribution

## Output Example

```
Original System: Happy (Confidence: 0.87)
New System: Balanced Expression (Confidence: 0.82)
```

## Use Cases

- **Interview Analysis**: Assess candidate expressiveness during video interviews
- **Communication Research**: Study facial expressiveness patterns
- **HR Applications**: Evaluate non-verbal communication skills

## Requirements

- Python 3.8+
- Webcam (for real-time recognition)
- 4GB+ RAM recommended
- GPU optional (TensorFlow will use CPU if no GPU available)

## Troubleshooting

### Virtual Environment Issues
```bash
# Recreate environment if needed
python -m venv facial_expressiveness_env --clear
facial_expressiveness_env\Scripts\activate
pip install -r requirements.txt
```

### Package Installation Issues
```bash
# Install packages individually
pip install numpy pandas matplotlib opencv-python tensorflow keras mediapipe
```

### Model Not Found
Run the notebook first to train the model:
```bash
jupyter notebook Facial_Expression_Expressiveness_Recognition.ipynb
```

## Comparison with Original System

This system provides the same **real-time output functionality** as the original live-face-emotion-classifier-main, but with these advantages:

1. **No Overlap**: Uses different technologies (MediaPipe + TensorFlow vs OpenCV + PyTorch)
2. **Better Domain Fit**: Trained on interview data instead of general faces
3. **More Relevant**: Expressiveness levels are more useful for interview analysis than basic emotions
4. **Modern Approach**: Uses Google's MediaPipe for more accurate face detection

The system maintains the same user experience - showing live video with bounding boxes and predictions - but provides more meaningful insights for interview evaluation.