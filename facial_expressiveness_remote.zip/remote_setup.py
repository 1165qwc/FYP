#!/usr/bin/env python3
"""
Remote Setup Script for Facial Expression Expressiveness Recognition
Run this on your remote Jupyter machine to set up the environment
"""

import subprocess
import sys
import os

def run_command(cmd, description=""):
    """Run a command and return success status"""
    try:
        print(f"[REMOTE] {description}")
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"[OK] {description}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"[FAILED] {description}")
        print(f"Error: {e.stderr}")
        return False

def main():
    print("Remote Setup for Facial Expression Expressiveness Recognition")
    print("=" * 65)

    # Check if we're in a virtual environment
    in_venv = hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)
    if not in_venv:
        print("[INFO] Consider creating a virtual environment:")
        print("       python -m venv facial_env")
        print("       facial_env\\Scripts\\activate  # Windows")
        print("       source facial_env/bin/activate  # Linux/Mac")
        print()

    # Install basic packages first
    print("Step 1: Installing basic scientific packages...")
    basic_packages = [
        "numpy",
        "pandas",
        "matplotlib",
        "seaborn",
        "scikit-learn",
        "tqdm",
        "jupyter"
    ]

    for package in basic_packages:
        run_command(f"pip install {package}", f"Installing {package}")

    # Install OpenCV
    print("\nStep 2: Installing OpenCV...")
    run_command("pip install opencv-python", "Installing OpenCV")

    # Install TensorFlow (takes longest)
    print("\nStep 3: Installing TensorFlow (this may take several minutes)...")
    run_command("pip install tensorflow", "Installing TensorFlow")

    # Install Keras
    print("\nStep 4: Installing Keras...")
    run_command("pip install keras", "Installing Keras")

    # Install MediaPipe
    print("\nStep 5: Installing MediaPipe...")
    run_command("pip install mediapipe", "Installing MediaPipe")

    print("\n[SUCCESS] Remote setup complete!")
    print("\nNext steps:")
    print("1. Upload your files to the remote machine:")
    print("   - Facial_Expression_Expressiveness_Recognition.ipynb")
    print("   - real_time_demo.py (optional)")
    print("   - test_system.py (optional)")
    print("   - FYP/RecruitView_Data/metadata.jsonl")
    print("   - FYP/RecruitView_Data/videos/ (if you want to train)")
    print()
    print("2. Open Jupyter: jupyter notebook")
    print("3. Open the notebook and run cells in order")
    print("4. The system will automatically create the models/ directory")

if __name__ == "__main__":
    main()