# Remote Setup Guide: Facial Expression Expressiveness Recognition

## 📁 Files to Transfer to Remote Machine

### **ESSENTIAL Files (Must Transfer)**
```
Facial_Expression_Expressiveness_Recognition.ipynb  # Main training notebook ⭐
requirements.txt                                    # Python dependencies ⭐
remote_setup.py                                     # Automated setup script ⭐
FYP/RecruitView_Data/metadata.jsonl                 # Dataset metadata ⭐
```

### **OPTIONAL Files (Recommended)**
```
real_time_demo.py                                    # Real-time webcam demo
test_system.py                                       # System testing script
README.md                                            # Quick reference
USAGE_GUIDE.md                                       # Detailed documentation
```

### **LARGE Files (Only if you want to train)**
```
FYP/RecruitView_Data/videos/                         # 1.8GB of video files
```

---

## 🚀 Setup Steps on Remote Machine

### **Step 1: Upload Files**
Use your preferred method to transfer files to the remote machine:
- **SCP/SFTP**: `scp files user@remote:/path/to/directory`
- **File Transfer**: Upload via Jupyter interface
- **Git**: Clone repository if available

### **Step 2: Run Automated Setup**
```bash
# Navigate to your project directory
cd /path/to/your/project

# Run the setup script
python remote_setup.py
```

**What the setup script installs:**
- numpy, pandas, matplotlib, seaborn
- scikit-learn, tqdm, jupyter
- opencv-python
- tensorflow (takes longest)
- keras
- mediapipe

### **Step 3: Alternative Manual Installation**
If the automated script fails, install manually:
```bash
# Basic packages
pip install numpy pandas matplotlib seaborn scikit-learn tqdm jupyter

# Computer vision
pip install opencv-python

# Deep learning (TensorFlow)
pip install tensorflow keras

# Face detection (MediaPipe)
pip install mediapipe
```

---

## 💻 Running on Remote Jupyter

### **Step 4: Start Jupyter Notebook**
```bash
# Start Jupyter server
jupyter notebook --no-browser --port=8889 --ip=0.0.0.0

# Or with specific settings
jupyter notebook --allow-root --port=8889 --ip=0.0.0.0
```

### **Step 5: Access Remote Jupyter**
- **Local Browser**: `http://remote-ip:8889`
- **SSH Tunnel**: `ssh -N -f -L localhost:8888:localhost:8889 user@remote`
- **Browser**: `http://localhost:8888`

### **Step 6: Open the Notebook**
1. In Jupyter interface, navigate to your project folder
2. Open: `Facial_Expression_Expressiveness_Recognition.ipynb`
3. Click **"Run All Cells"** or run cells sequentially

---

## 📊 Dataset Considerations

### **Option A: Full Training (Transfer Videos)**
- **Pros**: Complete training capability, best accuracy
- **Cons**: Large transfer (1.8GB), slow training
- **Requirements**: Transfer entire `FYP/RecruitView_Data/videos/` folder

### **Option B: Quick Demo (Metadata Only)**
- **Pros**: Fast setup, small transfer
- **Cons**: Limited training data, lower accuracy
- **Requirements**: Only transfer `metadata.jsonl`

### **Option C: Pre-trained Model**
- **Pros**: Instant setup, no training needed
- **Cons**: Can't customize model
- **Requirements**: Transfer `models/` directory (after training locally)

---

## ⚡ GPU Considerations

### **Check GPU Availability**
```python
import tensorflow as tf
print("GPU Available:", tf.config.list_physical_devices('GPU'))
```

### **GPU Setup (if available)**
```bash
# Install GPU version (if CUDA compatible)
pip install tensorflow-gpu

# Or install compatible version
pip install tensorflow==2.13.0  # For older CUDA versions
```

### **Expected Performance**
- **CPU Training**: 10-30 minutes per epoch
- **GPU Training**: 1-5 minutes per epoch
- **Real-time Demo**: Works on both CPU/GPU

---

## 🔧 Troubleshooting Remote Setup

### **Package Installation Issues**
```bash
# Upgrade pip first
pip install --upgrade pip

# Install packages individually
pip install --no-cache-dir package-name

# Use conda if pip fails
conda install package-name
```

### **Memory Issues**
```bash
# Reduce batch size in notebook
batch_size = 16  # Instead of 32

# Process fewer videos
sample_df = df.head(20)  # Instead of 50
```

### **Jupyter Connection Issues**
```bash
# Kill existing processes
pkill -f jupyter

# Start with different port
jupyter notebook --port=9999

# Allow all IPs
jupyter notebook --ip=0.0.0.0 --allow-root
```

### **Video Processing Issues**
```python
# Reduce frame extraction
faces = extract_frames_from_video(video_path, max_frames=1)  # Instead of 3

# Skip problematic videos
if os.path.exists(video_path):
    # Process video
else:
    print(f"Video not found: {video_path}")
```

---

## 📈 Training on Remote Machine

### **Monitor Training Progress**
- **Jupyter Interface**: Real-time output in notebook cells
- **System Resources**: Use `htop` or `nvidia-smi` to monitor
- **Expected Time**: 1-2 hours for full training

### **Save Trained Model**
After training completes, the model files are automatically saved:
```
models/
├── Facial_Expressiveness_Recognition_Model.h5
├── Facial_Expressiveness_Recognition_Model.json
├── expressiveness_model_weights.h5
└── label_encoder_classes.npy
```

### **Download Results**
- **Jupyter Interface**: Download files from file browser
- **SCP**: `scp user@remote:/path/to/models/* ./`
- **Web Interface**: Download via browser

---

## 🎯 Quick Start Commands

```bash
# 1. Upload files to remote machine
# (use your preferred file transfer method)

# 2. Run setup
python remote_setup.py

# 3. Start Jupyter
jupyter notebook --no-browser --port=8889 --ip=0.0.0.0 &

# 4. Access via browser
# http://remote-ip:8889

# 5. Open notebook and run training
# Facial_Expression_Expressiveness_Recognition.ipynb
```

---

## 📞 Support

### **Common Issues**
1. **"Module not found"**: Run `pip install -r requirements.txt`
2. **"No videos found"**: Check file paths in notebook
3. **"Out of memory"**: Reduce batch size and video count
4. **"Jupyter not accessible"**: Check firewall and port settings

### **Performance Optimization**
```python
# In notebook, modify these parameters:
max_frames = 1          # Reduce frames per video
batch_size = 16         # Smaller batches
epochs = 25            # Fewer epochs
sample_df = df.head(10) # Fewer videos
```

### **Backup Strategy**
- **Regular saves**: Model saves automatically every epoch
- **Checkpointing**: Use early stopping to save best model
- **Download frequently**: Save results to local machine

---

## ✅ Success Checklist

- [ ] Files uploaded to remote machine
- [ ] `python remote_setup.py` completed successfully
- [ ] Jupyter notebook accessible
- [ ] Notebook cells running without errors
- [ ] Model training completed
- [ ] `models/` directory created with saved files
- [ ] Real-time demo working (optional)

**You're all set for remote facial expression recognition! 🚀**